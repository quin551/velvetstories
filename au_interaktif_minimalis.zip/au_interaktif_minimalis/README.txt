# Template AU Interaktif — Sebelum Pukul Dua Belas

Website cerita interaktif yang mobile-first, minimalis, dan punya beberapa ending.

## Isi folder
- `index.html` — website lengkap; HTML, CSS, dan JavaScript sudah digabung agar gampang dipakai.
- Tombol pilihan membawa pembaca ke bagian cerita berbeda.
- Ada 3 ending yang bisa dicapai lewat jalur pilihan.
- Ada jejak pilihan, progress, tombol baca ulang, dan salin ending.
- Tidak membutuhkan library atau akun untuk dijalankan secara lokal.

## Cara mencoba di Android
1. Ekstrak ZIP ini.
2. Buka `index.html` dengan browser atau editor HTML yang mendukung preview.
3. Untuk mengedit isi cerita, cari bagian `const scenes = {` di dalam file.
4. Untuk mengubah judul utama, cari `Sebelum<br>pukul dua belas.`

## Cara menerbitkan gratis dengan Neocities
1. Buka https://neocities.org/ dan buat akun.
2. Masuk ke dashboard situs.
3. Unggah file `index.html` ke root website. Pastikan namanya persis `index.html`.
4. Buka alamat situs Neocities milikmu untuk mencoba website yang sudah online.

## Alternatif gratis: GitHub Pages
1. Buat akun di https://github.com/ lalu buat repository baru.
2. Unggah `index.html` ke repository.
3. Buka Settings → Pages.
4. Pada bagian build/deployment, pilih deploy from a branch, pilih branch `main` dan folder `/ (root)`, lalu Save.
5. Tunggu proses penerbitan, kemudian buka URL yang ditampilkan di halaman Pages.

## Cara mengubah alur cerita
Setiap bagian di dalam `scenes` punya:
- `label`: label bab.
- `title`: judul bab.
- `paragraphs`: daftar paragraf cerita. Awali teks dengan `quote: ` untuk menampilkan kutipan.
- `choices`: pilihan yang tampil sebagai tombol.
- `next`: ID bagian yang akan dibuka setelah tombol diklik.
- `ending`: label ending; bagian ending punya `choices: []`.

Untuk menambah ending baru, buat objek baru di `scenes` dengan `choices: []`, lalu arahkan pilihan ke ID ending tersebut. Semua ID harus sama persis, termasuk huruf besar/kecil.

## Catatan
Template tidak mengirim atau menyimpan data pribadi. Jejak pilihan hanya disimpan sementara selama halaman terbuka. Untuk mengganti cerita, edit file dan unggah ulang.
